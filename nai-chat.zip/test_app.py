"""배포 전 자체 점검. 외부 호출·클라우드 인증 없음."""
import io, zipfile
from util import (unzip_png, safe_name, build_zip, fit64, maybe_zip, build_payload,
                  clamp01, snap64, prep_i2i, prep_reference, clean_settings, join_tags,
                  DEFAULT_SETTINGS, is_v45, estimate_anlas, read_metadata, strip_metadata)


def test_unzip():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("image_0.png", b"\x89PNG_fake")
    assert unzip_png(buf.getvalue()) == b"\x89PNG_fake"


def test_safe_name():
    assert safe_name("사진.png") == "사진.png"
    # 경로를 넣어도 files/ 밖으로 못 나감
    assert safe_name("../../secret/a.png") == "a.png"
    assert safe_name("..\\..\\a.png") == "a.png"
    assert safe_name("a\x00b.png") == "ab.png"
    for bad in ["", "..", "dir/", "  "]:
        try:
            safe_name(bad)
        except ValueError:
            continue
        raise AssertionError(f"통과하면 안 됨: {bad!r}")


def test_build_zip():
    blob = build_zip([("a.txt", b"1"), ("그림.png", b"22")])
    z = zipfile.ZipFile(io.BytesIO(blob))
    assert sorted(z.namelist()) == ["a.txt", "그림.png"]
    assert z.read("그림.png") == b"22"


def test_maybe_zip():
    import os as _os
    big_text = b"hello " * 200_000                     # 1.2MB, 잘 줄어듦
    n, d, c = maybe_zip("log.txt", big_text, "text/plain", 1_000_000)
    assert n == "log.txt.zip" and c == "application/zip" and len(d) < len(big_text) // 10
    assert zipfile.ZipFile(io.BytesIO(d)).read("log.txt") == big_text   # 풀면 원본 그대로
    # 기준보다 작으면 그대로
    assert maybe_zip("log.txt", big_text, "text/plain", 5_000_000)[0] == "log.txt"
    # 안 줄어드는 파일(무작위 바이트)은 그대로
    assert maybe_zip("a.bin", _os.urandom(1_200_000), None, 1_000_000)[0] == "a.bin"
    # 이미지는 크기와 상관없이 그대로 (img2img 참고용)
    assert maybe_zip("a.png", big_text, "image/png", 1_000_000)[0] == "a.png"
    # 이미 zip이면 다시 싸지 않음
    assert maybe_zip("a.zip", big_text, None, 1_000_000)[0] == "a.zip"


def test_fit64():
    assert fit64(832, 1216) == (832, 1216)
    w, h = fit64(3000, 2000)
    assert w % 64 == 0 and h % 64 == 0 and max(w, h) <= 1216 + 32


def test_build_payload_plain():
    b = build_payload("1girl", "lowres", 832, 1216, 7)
    p = b["parameters"]
    assert b["action"] == "generate" and b["model"] == "nai-diffusion-4-5-full"
    # V4.5 웹 클라이언트가 보내는 구조
    assert p["v4_prompt"]["caption"]["base_caption"] == "1girl"
    assert p["v4_negative_prompt"]["caption"]["base_caption"] == "lowres"
    assert p["params_version"] == 3 and p["seed"] == 7
    assert "image" not in p and "director_reference_images" not in p


def test_build_payload_i2i():
    p = build_payload("x", i2i={"image": "B64", "strength": 0.35, "noise": 0.1}, seed=5)["parameters"]
    assert p["image"] == "B64" and p["strength"] == 0.35 and p["noise"] == 0.1
    assert p["extra_noise_seed"] == 5
    assert build_payload("x", i2i={"image": "B64"})["action"] == "img2img"


def test_build_payload_reference():
    p = build_payload("x", ref={"image": "R", "type": "style", "strength": 0.8, "fidelity": 0.7})["parameters"]
    assert p["director_reference_images"] == ["R"]
    assert p["director_reference_descriptions"] == [
        {"caption": {"base_caption": "style", "char_captions": []}, "legacy_uc": False}]
    assert p["director_reference_strength_values"] == [0.8]
    assert p["director_reference_secondary_strength_values"] == [0.3]   # 1 - 충실도
    assert p["director_reference_information_extracted"] == [1.0]
    # 모르는 종류는 기본값으로
    q = build_payload("x", ref={"image": "R", "type": "hack"})["parameters"]
    assert q["director_reference_descriptions"][0]["caption"]["base_caption"] == "character&style"
    # 레퍼런스만 쓰면 action은 generate
    assert build_payload("x", ref={"image": "R"})["action"] == "generate"


def test_clamp_snap():
    assert clamp01(1.7, .5) == 1.0 and clamp01(-3, .5) == 0.0 and clamp01("abc", .5) == .5
    assert snap64(1000, 832) == 1024 and snap64(9999, 832) == 1600 and snap64(10, 832) == 64
    assert snap64(None, 832) == 832


def test_prep_images():
    import base64
    from PIL import Image
    src = io.BytesIO(); Image.new("RGB", (1000, 700), "red").save(src, "PNG")
    b64, w, h = prep_i2i(src.getvalue())
    assert (w, h) == (1024, 704) and w % 64 == 0 and h % 64 == 0
    ref = Image.open(io.BytesIO(base64.b64decode(prep_reference(src.getvalue()))))
    assert ref.size == (1024, 1536)
    assert ref.getpixel((512, 5)) == (0, 0, 0) and ref.getpixel((512, 768)) == (255, 0, 0)


def test_clean_settings():
    s = clean_settings({"model": "nai-diffusion-5-full", "steps": 99, "scale": -3,
                        "sampler": "k_dpmpp_2m", "prefix": "  artist:foo, ", "width": 1000})
    assert s["model"] == "nai-diffusion-5-full" and s["steps"] == 50 and s["scale"] == 0
    assert s["sampler"] == "k_dpmpp_2m" and s["prefix"] == "artist:foo," and s["width"] == 1024
    # 이전 값 위에 부분 수정, 이상한 값은 무시
    t = clean_settings({"model": "gpt-4", "sampler": "hack", "steps": "abc", "negative": "lowres"}, s)
    assert t["model"] == "nai-diffusion-5-full" and t["sampler"] == "k_dpmpp_2m" and t["steps"] == 50
    assert t["negative"] == "lowres" and t["prefix"] == "artist:foo,"
    assert "suffix" not in t


def test_old_suffix_migrates():
    # 예전 판에 저장된 '고정 프롬프트(뒤)'는 한 칸으로 합쳐지고 사라지지 않는다
    saved = {"prefix": "artist:foo", "suffix": "masterpiece, very aesthetic"}
    s = clean_settings(saved)
    assert s["prefix"] == "artist:foo, masterpiece, very aesthetic" and "suffix" not in s
    # 다시 저장했다 불러와도 두 번 붙지 않는다
    assert clean_settings(s)["prefix"] == s["prefix"]
    assert clean_settings(None) == DEFAULT_SETTINGS
    assert isinstance(clean_settings({"steps": 30.7})["steps"], int)


def test_join_tags():
    assert join_tags("artist:foo,", "1girl, smile", " masterpiece ") == "artist:foo, 1girl, smile, masterpiece"
    assert join_tags("", "1girl", "") == "1girl"
    assert join_tags(" , ", "1girl") == "1girl"


def test_payload_by_model():
    v3 = build_payload("x", model="nai-diffusion-3")["parameters"]
    assert "v4_prompt" not in v3 and "v4_negative_prompt" not in v3
    v5 = build_payload("x", model="nai-diffusion-5-full")["parameters"]
    assert v5["v4_prompt"]["caption"]["base_caption"] == "x"
    o = build_payload("x", opts={"steps": 35, "scale": 6.5, "sampler": "k_euler",
                                 "noise_schedule": "exponential", "cfg_rescale": 0.2})["parameters"]
    assert (o["steps"], o["scale"], o["sampler"], o["noise_schedule"], o["cfg_rescale"]) ==            (35, 6.5, "k_euler", "exponential", 0.2)
    assert is_v45("nai-diffusion-4-5-curated") and not is_v45("nai-diffusion-5-full")


def test_estimate_anlas():
    # 손으로 계산한 SDK 공식 값: 832x1216 28스텝 = ceil(2.986 + 16.298) = 20
    assert estimate_anlas(832, 1216, 28)[0] == 20
    assert estimate_anlas(832, 1216, 28, is_opus=True)[0] == 0          # Opus 무료 범위
    assert estimate_anlas(832, 1216, 29, is_opus=True)[0] > 0           # 스텝 29부터 유료
    assert estimate_anlas(1024, 1536, 28, is_opus=True)[0] == 30        # 1MP 초과면 유료
    assert estimate_anlas(832, 1216, 28, refs=1, is_opus=True)[0] == 5  # 레퍼런스는 무료여도 +5
    assert estimate_anlas(832, 1216, 28, i2i_strength=0.5)[0] == 10     # I2I는 강도를 곱함
    assert estimate_anlas(64, 64, 1, i2i_strength=0.0)[0] == 2          # 최소 2
    assert estimate_anlas(1600, 1600, 50)[0] == 82                      # 이 앱의 최대치


COMMENT = {"prompt": "1girl, smile", "uc": "old uc", "steps": 28, "scale": 5, "cfg_rescale": 0,
           "sampler": "k_euler_ancestral", "noise_schedule": "karras", "width": 832, "height": 1216,
           "seed": 12345,
           "v4_prompt": {"caption": {"base_caption": "1girl, smile, v4", "char_captions": []}},
           "v4_negative_prompt": {"caption": {"base_caption": "lowres, bad hands", "char_captions": []}}}


def _png(img, **text):
    from PIL.PngImagePlugin import PngInfo
    meta = PngInfo()
    for k, v in text.items():
        meta.add_text(k, v)
    b = io.BytesIO(); img.save(b, "PNG", pnginfo=meta); return b.getvalue()


def test_meta_novelai_text():
    import json
    from PIL import Image
    data = _png(Image.new("RGB", (64, 64)), Software="NovelAI", Description="desc",
                Source="NovelAI Diffusion V4.5 4BDE2A90", Comment=json.dumps(COMMENT))
    m = read_metadata(data)
    assert m["source"] == "novelai" and m["prompt"] == "1girl, smile, v4"
    assert m["negative"] == "lowres, bad hands"                    # v4 네거티브가 우선
    assert m["params"]["steps"] == 28 and m["params"]["seed"] == 12345
    assert m["model_guess"] == "nai-diffusion-4-5-full"


def _stealth_img():
    """공식 규격대로 알파 LSB에 세로 줄 순서로 메타데이터를 심은 그림 (텍스트 청크 없음)."""
    import gzip, json
    from PIL import Image
    w, h = 40, 60
    payload = gzip.compress(json.dumps({"Software": "NovelAI", "Source": "NovelAI Diffusion V4 X",
                                        "Comment": json.dumps(COMMENT)}).encode())
    raw = b"stealth_pngcomp" + (len(payload) * 8).to_bytes(4, "big") + payload
    bits = [(byte >> (7 - i)) & 1 for byte in raw for i in range(8)]
    assert len(bits) <= w * h
    img = Image.new("RGBA", (w, h), (10, 20, 30, 255)); px = img.load()
    for k, bit in enumerate(bits):
        x, y = divmod(k, h)                                   # 세로 줄 순서
        r, g, b, a = px[x, y]; px[x, y] = (r, g, b, (a & 0xFE) | bit)
    return img


def test_meta_novelai_stealth():
    m = read_metadata(_png(_stealth_img()))
    assert m["source"] == "novelai-stealth" and m["negative"] == "lowres, bad hands", m
    assert m["model_guess"] == "nai-diffusion-4-full"


def test_strip_metadata():
    import json
    from PIL import Image
    # 텍스트 청크와 알파 채널을 둘 다 가진 NovelAI PNG
    img = _stealth_img()
    src = _png(img, Software="NovelAI", Comment=json.dumps(COMMENT))
    assert read_metadata(src)["found"]
    out, ext = strip_metadata(src)
    assert ext == ".png" and read_metadata(out)["found"] is False
    o = Image.open(io.BytesIO(out))
    assert "Comment" not in o.info and o.size == img.size
    assert o.convert("RGB").tobytes() == img.convert("RGB").tobytes()   # 색은 그대로
    # JPEG EXIF (A1111 파라미터 + 회전값) — 정보는 지우고 방향은 픽셀에 반영
    j = Image.new("RGB", (20, 10), "blue"); ex = j.getexif(); ex[0x0112] = 6
    ex.get_ifd(0x8769)[0x9286] = b"ASCII" + bytes(3) + b"Steps: 20"
    b = io.BytesIO(); j.save(b, "JPEG", exif=ex.tobytes())
    out, ext = strip_metadata(b.getvalue())
    o = Image.open(io.BytesIO(out))
    assert ext == ".jpg" and not o.getexif() and o.size == (10, 20)
    assert read_metadata(out)["found"] is False


NL = chr(10)


def test_meta_a1111_and_jpeg():
    from PIL import Image
    text = ("masterpiece, 1girl" + NL + "Negative prompt: worst quality, blurry" + NL + "Steps: 30, Sampler: Euler a, CFG scale: 7, Seed: 99, Size: 512x768")
    m = read_metadata(_png(Image.new("RGB", (8, 8)), parameters=text))
    assert m["source"] == "a1111" and m["prompt"] == "masterpiece, 1girl"
    assert m["negative"] == "worst quality, blurry"
    assert m["params"] == {"steps": 30, "scale": 7.0, "seed": 99, "width": 512, "height": 768}
    # JPEG EXIF UserComment (UNICODE + UTF-16BE)
    img = Image.new("RGB", (8, 8)); ex = img.getexif()
    ex.get_ifd(0x8769)[0x9286] = b"UNICODE" + bytes([0]) + text.encode("utf-16-be")
    b = io.BytesIO(); img.save(b, "JPEG", exif=ex.tobytes())
    j = read_metadata(b.getvalue())
    assert j["source"] == "a1111" and j["negative"] == "worst quality, blurry", j


def test_meta_none():
    from PIL import Image
    assert read_metadata(_png(Image.new("RGBA", (30, 30), (0, 0, 0, 255))))["found"] is False


if __name__ == "__main__":
    test_unzip(); test_safe_name(); test_build_zip(); test_maybe_zip(); test_fit64()
    test_build_payload_plain(); test_build_payload_i2i(); test_build_payload_reference()
    test_clamp_snap(); test_prep_images()
    test_clean_settings(); test_old_suffix_migrates(); test_join_tags(); test_payload_by_model()
    test_estimate_anlas()
    test_meta_novelai_text(); test_meta_novelai_stealth(); test_meta_a1111_and_jpeg(); test_meta_none()
    test_strip_metadata()
    print("OK")
