import base64, hmac, json, os, secrets, time
from functools import wraps
from urllib.parse import quote

import requests
from flask import Flask, request, jsonify, Response
from google import genai
from google.genai import types
from google.cloud import storage

from util import (unzip_png, safe_name, build_zip, maybe_zip, build_payload,
                  prep_i2i, prep_reference, clamp01, snap64, REF_TYPES,
                  MODELS, SAMPLERS, NOISE_SCHEDULES, DEFAULT_SETTINGS,
                  clean_settings, join_tags, is_v45, estimate_anlas, read_metadata,
                  strip_metadata)

NAI_URL = "https://image.novelai.net/ai/generate-image"
SUB_URL = "https://image.novelai.net/user/subscription"   # api.novelai.net/user/* 는 은퇴함 (novelai-sdk)
TIERS = {0: "Paper", 1: "Tablet", 2: "Scroll", 3: "Opus"}
PASSWORD = os.environ.get("APP_PASSWORD", "")
MODEL = os.environ.get("MODEL", "gemini-2.5-flash")
PREFIX = "files/"
SETTINGS_KEY = "config/settings.json"      # files/ 밖이라 보관함 목록에 안 뜬다
ZIP_OVER = int(float(os.environ.get("ZIP_OVER_MB", "5")) * 1024 * 1024)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 30 * 1024 * 1024   # 클라우드 런 요청 한도 32MB 아래
app.json.sort_keys = False                              # 모델 목록을 최신순 그대로 보낸다
client = genai.Client(vertexai=True,
                      project=os.environ["GOOGLE_CLOUD_PROJECT"],
                      location=os.environ.get("LOCATION", "global"))
bucket = storage.Client().bucket(os.environ["BUCKET"])


def blob(name):
    return bucket.blob(PREFIX + safe_name(name))


def authed(f):
    @wraps(f)
    def w(*a, **k):
        if PASSWORD and not hmac.compare_digest(request.headers.get("X-Password", ""), PASSWORD):
            return jsonify(error="비밀번호가 틀렸습니다"), 401
        return f(*a, **k)
    return w


def attachment(data, name, ctype="application/octet-stream"):
    return Response(data, mimetype=ctype, headers={
        "Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"})


# ---------- 파일 ----------

def list_names(limit=100):
    bs = sorted(bucket.list_blobs(prefix=PREFIX), key=lambda b: b.updated, reverse=True)
    return [{"name": b.name[len(PREFIX):], "size": b.size,
             "updated": b.updated.isoformat(), "type": b.content_type} for b in bs[:limit]]


def save_zip(names, zip_name="files.zip"):
    items = [(safe_name(n), blob(n).download_as_bytes()) for n in names]
    zip_name = safe_name(zip_name if zip_name.endswith(".zip") else zip_name + ".zip")
    blob(zip_name).upload_from_string(build_zip(items), content_type="application/zip")
    return zip_name


@app.get("/api/files")
@authed
def api_files():
    return jsonify(files=list_names())


@app.post("/api/upload")
@authed
def api_upload():
    saved, zipped = [], []
    for f in request.files.getlist("file"):
        name, data, ctype = maybe_zip(safe_name(f.filename), f.read(), f.mimetype, ZIP_OVER)
        blob(name).upload_from_string(data, content_type=ctype or None)
        saved.append(name)
        if name != safe_name(f.filename):
            zipped.append(name)
    return jsonify(saved=saved, zipped=zipped)


@app.get("/api/file/<path:name>")
@authed
def api_download(name):
    b = blob(name)
    if not b.exists():
        return jsonify(error="파일이 없습니다"), 404
    b.reload()
    return attachment(b.download_as_bytes(), safe_name(name), b.content_type or "application/octet-stream")


@app.delete("/api/file/<path:name>")
@authed
def api_delete(name):
    b = blob(name)
    if b.exists():
        b.delete()
    return jsonify(ok=True)


def image_metadata(name):
    m = read_metadata(read_file(name))
    m["file"] = safe_name(name)
    if m["model_guess"]:
        m["model_label"] = MODELS[m["model_guess"]]
    return m


def remove_metadata(name):
    """생성 정보를 지운 사본을 '이름-noexif.확장자'로 저장한다. 원본은 그대로 둔다."""
    data, ext = strip_metadata(read_file(name))
    base = safe_name(name).rsplit(".", 1)[0]
    out = safe_name(base + "-noexif" + ext)
    ctype = {".jpg": "image/jpeg", ".webp": "image/webp"}.get(ext, "image/png")
    blob(out).upload_from_string(data, content_type=ctype)
    return out


@app.post("/api/zip")
@authed
def api_zip():
    names = request.get_json(force=True).get("names") or []
    if not names:
        return jsonify(error="파일을 골라주세요"), 400
    # ponytail: 메모리에서 묶음. 수백 MB를 넘기면 스트리밍 zip으로 바꿀 것
    data = build_zip([(safe_name(n), blob(n).download_as_bytes()) for n in names])
    return attachment(data, "files.zip", "application/zip")


# ---------- 고정 설정 ----------

def load_settings():
    base = clean_settings({"model": os.environ.get("NAI_MODEL")} if os.environ.get("NAI_MODEL") else {})
    try:
        b = bucket.blob(SETTINGS_KEY)
        if b.exists():
            return clean_settings(json.loads(b.download_as_bytes()), base)
    except Exception:
        app.logger.exception("설정 읽기 실패 — 기본값으로 진행")
    return base


def save_settings(changes):
    s = clean_settings(changes, load_settings())
    bucket.blob(SETTINGS_KEY).upload_from_string(
        json.dumps(s, ensure_ascii=False), content_type="application/json")
    return s


@app.get("/api/settings")
@authed
def api_settings_get():
    return jsonify(settings=load_settings(), models=MODELS,
                   samplers=SAMPLERS, noise_schedules=NOISE_SCHEDULES)


@app.post("/api/settings")
@authed
def api_settings_post():
    return jsonify(settings=save_settings(request.get_json(force=True)))


# ---------- NovelAI ----------

def read_file(name):
    b = blob(name)
    if not b.exists():
        raise ValueError(f"보관함에 없는 파일: {safe_name(name)}")
    return b.download_as_bytes()


def nai_auth():
    return {"Authorization": "Bearer " + os.environ["NAI_TOKEN"]}


def account():
    """잔액과 Opus 여부. 못 읽으면 Opus가 아닌 것으로 본다 — 모르면 묻는 쪽이 안전하다."""
    try:
        r = requests.get(SUB_URL, headers=nai_auth(), timeout=15)
        r.raise_for_status()
        j = r.json()
        t = j.get("trainingStepsLeft") or {}
        return {"anlas": int(t.get("fixedTrainingStepsLeft", 0)) + int(t.get("purchasedTrainingSteps", 0)),
                "is_opus": j.get("tier") == 3 or bool((j.get("perks") or {}).get("unlimitedImageGeneration")),
                "tier": TIERS.get(j.get("tier"), "?")}
    except Exception:
        app.logger.exception("구독 정보 읽기 실패")
        return {"anlas": None, "is_opus": False, "tier": "?"}


@app.get("/api/account")
@authed
def api_account():
    return jsonify(account())


class NeedConfirm(Exception):
    """아날스가 드는 생성은 사용자가 승인해야 시작한다."""
    def __init__(self, info):
        super().__init__("아날스 확인 필요")
        self.info = info


def cost_of(body, acct):
    p = body["parameters"]
    return estimate_anlas(p["width"], p["height"], p["steps"],
                          p.get("strength") if "image" in p else None,
                          len(p.get("director_reference_images") or []), acct["is_opus"])


def prepare(prompt, negative_prompt="", width=None, height=None, seed=0,
             i2i_file=None, strength=0.6, noise=0.0,
             reference_file=None, reference_type="character&style",
             reference_strength=1.0, reference_fidelity=1.0, **_ignored):
    """NovelAI로 보낼 요청과 실제로 쓴 설정을 만든다. 아직 보내지 않는다.
    고정 설정(모델·고정 프롬프트·스텝·가이던스 등)은 여기서 매번 붙는다."""
    cfg = load_settings()
    try:
        seed = int(seed or 0) % 2**32
    except (TypeError, ValueError):
        seed = 0
    seed = seed or secrets.randbelow(2**32 - 1) + 1
    width, height = snap64(width, cfg["width"]), snap64(height, cfg["height"])
    used = {"prompt": prompt, "negative_prompt": negative_prompt, "seed": seed,
            "i2i_file": None, "strength": clamp01(strength, 0.6), "noise": clamp01(noise, 0.0),
            "reference_file": None,
            "reference_type": reference_type if reference_type in REF_TYPES else REF_TYPES[0],
            "reference_strength": clamp01(reference_strength, 1.0),
            "reference_fidelity": clamp01(reference_fidelity, 1.0)}
    i2i = ref = None
    if i2i_file:
        b64, width, height = prep_i2i(read_file(i2i_file))
        i2i = {"image": b64, "strength": used["strength"], "noise": used["noise"]}
        used["i2i_file"] = safe_name(i2i_file)
    if reference_file:
        if not is_v45(cfg["model"]):
            raise ValueError(f"정밀 레퍼런스는 V4.5 모델에서만 됩니다 (지금: {MODELS[cfg['model']]})")
        ref = {"image": prep_reference(read_file(reference_file)),
               "type": used["reference_type"], "strength": used["reference_strength"],
               "fidelity": used["reference_fidelity"]}
        used["reference_file"] = safe_name(reference_file)
    final_prompt = join_tags(cfg["prefix"], prompt)
    final_negative = join_tags(cfg["negative"], negative_prompt)
    used.update(width=width, height=height, model=cfg["model"], final_prompt=final_prompt,
                final_negative=final_negative,
                **{k: cfg[k] for k in ("steps", "scale", "sampler", "noise_schedule", "cfg_rescale")})
    body = build_payload(final_prompt, final_negative, width, height, seed,
                         cfg["model"], i2i, ref, opts=cfg)
    return body, used


def send(body):
    r = requests.post(NAI_URL, headers=nai_auth(), json=body, timeout=180)
    r.raise_for_status()
    return unzip_png(r.content)


def generate_and_save(args):
    """아날스가 0이면 바로 뽑는다. 1 이상이면 confirm_anlas로 그 값 이상을 승인받아야 뽑는다.
    승인 검사를 서버에서 하므로 화면에 버그가 있어도 허락 없이 아날스가 빠지지 않는다."""
    args = dict(args)
    confirm = args.pop("confirm_anlas", None)
    body, used = prepare(**args)
    acct = account()
    cost, detail = cost_of(body, acct)
    try:
        approved = confirm is not None and int(confirm) >= cost
    except (TypeError, ValueError):
        approved = False
    if cost > 0 and not approved:
        raise NeedConfirm({"cost": cost, "detail": detail, "balance": acct["anlas"], "tier": acct["tier"],
                           "enough": acct["anlas"] is None or acct["anlas"] >= cost, "args": args})
    png = send(body)
    spent = None
    if cost > 0 and acct["anlas"] is not None:
        after = account()["anlas"]
        spent = None if after is None else acct["anlas"] - after
    used.update(anlas_estimate=cost, anlas_spent=spent)
    name = time.strftime("gen-%Y%m%d-%H%M%S-") + secrets.token_hex(2) + ".png"
    try:
        blob(name).upload_from_string(png, content_type="image/png")
    except Exception:
        app.logger.exception("생성 이미지 저장 실패")   # 저장이 실패해도 그림은 보여준다
        name = None
    return {"name": name, "src": "data:image/png;base64," + base64.b64encode(png).decode(),
            "params": used}


@app.post("/api/generate")
@authed
def api_generate():
    """설정 패널에서 제미나이를 거치지 않고 값 그대로 다시 뽑는다."""
    try:
        return jsonify(image=generate_and_save(request.get_json(force=True)))
    except NeedConfirm as e:
        return jsonify(need_confirm=True, **e.info), 409
    except requests.HTTPError as e:
        return jsonify(error=f"NovelAI {e.response.status_code}: {e.response.text[:300]}"), 502
    except ValueError as e:
        return jsonify(error=str(e)), 400
    except Exception as e:
        app.logger.exception("직접 생성 실패")
        return jsonify(error=f"{type(e).__name__}: {e}"), 500


# ---------- 제미나이 도구 ----------

TOOL = types.Tool(function_declarations=[
    {"name": "generate_image",
     "description": "NovelAI로 이미지를 생성한다. prompt는 영어 태그를 쉼표로 나열한 형식이어야 한다. "
                    "올린 그림을 쓰는 방법은 둘이다. "
                    "i2i_file: 그 그림의 구도·포즈를 살린 채 변형(옷만 바꾸기, 색 바꾸기 등). "
                    "reference_file: 구도는 새로 잡고 그 그림의 캐릭터·화풍만 따라감(같은 캐릭터로 다른 장면). "
                    "사용자가 어느 쪽인지 말하지 않으면 '비슷하게·이 캐릭터로'는 reference_file, "
                    "'이 그림에서 ~만 바꿔'는 i2i_file로 판단한다.",
     "parameters": {"type": "object", "properties": {
         "prompt": {"type": "string", "description": "예: 1girl, blue hair, smile, school uniform"},
         "negative_prompt": {"type": "string"},
         "width": {"type": "integer"}, "height": {"type": "integer"},
         "seed": {"type": "integer"},
         "i2i_file": {"type": "string", "description": "I2I 원본으로 쓸 보관함 파일 이름"},
         "strength": {"type": "number", "description": "I2I 강도 0~1. 클수록 원본에서 많이 바뀜. 기본 0.6"},
         "noise": {"type": "number", "description": "I2I 노이즈 0~1. 기본 0"},
         "reference_file": {"type": "string", "description": "정밀 레퍼런스로 쓸 보관함 파일 이름"},
         "reference_type": {"type": "string", "enum": list(REF_TYPES),
                            "description": "character=캐릭터만, style=화풍만, character&style=둘 다"},
         "reference_strength": {"type": "number", "description": "0~1. 기본 1"},
         "reference_fidelity": {"type": "number", "description": "0~1. 높을수록 표정·포즈까지 닮음. 기본 1"}},
         "required": ["prompt"]}},
    {"name": "update_settings",
     "description": "모든 생성에 계속 적용되는 고정 설정을 바꾼다. 사용자가 모델을 바꾸라거나"
                    "(예: '5 full로', '4.5 curated로', 'V3로'), 고정 프롬프트·고정 네거티브·스텝·가이던스·"
                    "샘플러·기본 크기를 정하라고 하면 호출한다. 바꾸라고 한 항목만 넣는다.",
     "parameters": {"type": "object", "properties": {
         "model": {"type": "string", "enum": list(MODELS)},
         "prefix": {"type": "string", "description": "매번 프롬프트 맨 앞에 붙는 고정 태그. 그림체·작가·품질 태그 등"},
         "negative": {"type": "string", "description": "매번 붙는 고정 네거티브"},
         "steps": {"type": "integer", "description": "1~50"},
         "scale": {"type": "number", "description": "프롬프트 가이던스 0~10"},
         "cfg_rescale": {"type": "number", "description": "0~1"},
         "sampler": {"type": "string", "enum": list(SAMPLERS)},
         "noise_schedule": {"type": "string", "enum": list(NOISE_SCHEDULES)},
         "width": {"type": "integer"}, "height": {"type": "integer"}}}},
    {"name": "read_image_metadata",
     "description": "보관함 그림에 들어 있는 생성 정보(EXIF·PNG 메타데이터)를 읽는다. "
                    "프롬프트·네거티브·스텝·가이던스·샘플러·크기·시드와 추정 모델을 돌려준다. "
                    "사용자가 'EXIF 추출', '이 그림 프롬프트 뭐야', '이 그림 네거티브 가져와' 같은 말을 하면 쓴다. "
                    "'고정 네거티브에 넣어'라고 하면 읽은 negative를 update_settings의 negative로 넣는다. "
                    "읽은 결과는 프롬프트·네거티브·파라미터를 한국어로 정리해 답에 보여준다. 정보가 없으면(found=false) "
                    "SNS나 메신저를 거치며 지워졌을 수 있다고 알린다. "
                    "파일을 콕 집지 않으면 list_files로 가장 최근에 올린 그림을 쓴다.",
     "parameters": {"type": "object", "properties": {
         "file": {"type": "string", "description": "보관함 파일 이름"}}, "required": ["file"]}},
    {"name": "strip_metadata",
     "description": "보관함 그림에서 생성 정보·EXIF·위치 정보·NovelAI 알파 채널 정보를 모두 지운 사본을 만든다. "
                    "원본은 그대로 두고 '이름-noexif.확장자'로 저장한다. 'EXIF 제거', '메타데이터 지워줘', "
                    "'프롬프트 안 보이게 해줘' 같은 말에 쓴다. 파일을 콕 집지 않으면 list_files로 가장 최근 그림을 쓴다.",
     "parameters": {"type": "object", "properties": {
         "file": {"type": "string", "description": "보관함 파일 이름"}}, "required": ["file"]}},
    {"name": "list_files",
     "description": "보관함에 있는 파일 목록을 최신순으로 돌려준다.",
     "parameters": {"type": "object", "properties": {}}},
    {"name": "make_zip",
     "description": "보관함 파일 여러 개를 zip 하나로 묶어 보관함에 저장한다.",
     "parameters": {"type": "object", "properties": {
         "names": {"type": "array", "items": {"type": "string"}},
         "zip_name": {"type": "string"}}, "required": ["names"]}},
])

SYSTEM = ("너는 NovelAI 이미지 생성과 파일 정리를 돕는다. 사용자가 한국어로 원하는 그림을 말하면 "
          "generate_image를 호출한다. prompt는 반드시 영어 태그를 쉼표로 나열한 형식으로 만들고, "
          "품질 태그와 구체적인 묘사 태그를 충분히 넣는다. 생성 후에는 어떤 태그를 썼는지 한국어로 짧게 알려준다. "
          "사용자가 올린 파일이나 이전에 만든 그림을 가리키면 list_files로 이름을 확인한 뒤 쓴다. "
          "파일을 묶어 달라고 하면 make_zip을 쓴다.")


def run_tool(name, args, images, files, pending):
    if name == "generate_image":
        args.pop("confirm_anlas", None)          # 승인은 사람만 한다. 제미나이가 넣은 값은 버린다
        try:
            im = generate_and_save(args)
        except NeedConfirm as e:
            pending.append(e.info)
            return {"ok": False, "waiting_for_user": True, "anlas_cost": e.info["cost"],
                    "balance": e.info["balance"],
                    "note": "아날스가 드는 생성이라 사용자가 화면에서 승인해야 시작된다. "
                            "예상 소모량과 잔액을 한국어로 짧게 알리고, 다시 호출하지 말고 기다려라."}
        images.append(im)
        return {"ok": True, "saved_as": im["name"], "used": im["params"]}
    if name == "update_settings":
        return {"ok": True, "settings": save_settings(args)}
    if name == "read_image_metadata":
        return image_metadata(args["file"])
    if name == "strip_metadata":
        out = remove_metadata(args["file"])
        files.append(out)
        return {"ok": True, "saved_as": out, "original_kept": True}
    if name == "list_files":
        return {"files": [f["name"] for f in list_names(50)]}
    if name == "make_zip":
        z = save_zip(args["names"], args.get("zip_name") or "files.zip")
        files.append(z)
        return {"ok": True, "saved_as": z}
    return {"ok": False, "error": "알 수 없는 도구"}


def root_cause(e):
    """google-genai는 재시도 후 RetryError로 감싸 진짜 원인을 가린다."""
    last = getattr(e, "last_attempt", None)
    return last.exception() if last and last.exception() else e


@app.post("/api/chat")
@authed
def api_chat():
    body = request.get_json(force=True)
    history = [types.Content(role=h["role"], parts=[types.Part(text=h["text"])])
               for h in body.get("history", [])]
    cfg = load_settings()
    system = "\n".join([
        SYSTEM, "",
        f"[지금 고정 설정] 모델={MODELS[cfg['model']]} 스텝={cfg['steps']} 가이던스={cfg['scale']} "
        f"샘플러={cfg['sampler']} 기본크기={cfg['width']}x{cfg['height']}",
        f"고정 프롬프트='{cfg['prefix']}' 고정 네거티브='{cfg['negative']}'",
        "고정 프롬프트와 고정 네거티브는 서버가 자동으로 붙인다. generate_image의 prompt에 다시 넣지 말 것.",
        "정밀 레퍼런스(reference_file)는 V4.5 모델에서만 된다. 다른 모델이면 쓰지 말고 사용자에게 알린다."])
    chat = client.chats.create(model=MODEL, history=history,
        config=types.GenerateContentConfig(tools=[TOOL], system_instruction=system))

    images, files, pending = [], [], []
    try:
        res = chat.send_message(body["message"])
        for _ in range(4):                      # 연속 호출 대비
            calls = [p.function_call for p in (res.candidates[0].content.parts or [])
                     if p.function_call]
            if not calls:
                break
            replies = []
            for c in calls:
                try:
                    out = run_tool(c.name, dict(c.args or {}), images, files, pending)
                except requests.HTTPError as e:
                    out = {"ok": False, "error": f"NovelAI {e.response.status_code}: {e.response.text[:200]}"}
                except Exception as e:
                    app.logger.exception("도구 실패: %s", c.name)
                    out = {"ok": False, "error": f"{type(e).__name__}: {e}"}
                replies.append(types.Part.from_function_response(name=c.name, response=out))
            res = chat.send_message(replies)
    except Exception as e:
        e = root_cause(e)
        app.logger.exception("채팅 실패")
        return jsonify(error=f"{type(e).__name__}: {e}"), 500

    return jsonify(text=res.text or "", images=images, files=files, pending=pending)


@app.get("/")
def index():
    return Response(PAGE, mimetype="text/html")


PAGE = open(os.path.join(os.path.dirname(__file__), "index.html"), encoding="utf-8").read()
