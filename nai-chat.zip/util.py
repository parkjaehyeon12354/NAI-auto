import io, re, zipfile


def unzip_png(blob):
    """NovelAI는 zip으로 응답한다. 첫 항목이 png다."""
    z = zipfile.ZipFile(io.BytesIO(blob))
    return z.read(z.namelist()[0])


def safe_name(name):
    """사용자가 준 파일 이름을 버킷 키로 쓸 수 있게 정리한다.
    경로 구분자를 떼어 files/ 밖의 키를 가리키지 못하게 막는다."""
    name = str(name).replace("\\", "/").split("/")[-1]
    name = re.sub(r"[\x00-\x1f\x7f]", "", name).strip()
    if name in ("", ".", ".."):
        raise ValueError("잘못된 파일 이름입니다")
    return name[:200]


def build_zip(items):
    """[(이름, bytes), ...] → zip bytes"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in items:
            z.writestr(name, data)
    return buf.getvalue()


def maybe_zip(name, data, ctype, over_bytes, min_saving=0.10):
    """큰 파일은 zip으로 바꿔 저장한다. 실제로 min_saving 이상 줄어들 때만.
    이미지는 img2img 참고용으로 써야 하고 어차피 거의 안 줄어서 건드리지 않는다."""
    if len(data) < over_bytes or (ctype or "").startswith("image/") or name.lower().endswith(".zip"):
        return name, data, ctype
    packed = build_zip([(name, data)])
    if len(packed) > len(data) * (1 - min_saving):
        return name, data, ctype
    return name + ".zip", packed, "application/zip"


def fit64(w, h, long_side=1216):
    """NovelAI는 가로세로가 64의 배수여야 한다. 비율을 지키며 맞춘다."""
    s = min(1.0, long_side / max(w, h))
    return max(64, round(w * s / 64) * 64), max(64, round(h * s / 64) * 64)


def snap64(v, default):
    """사용자가 넣은 크기를 64 배수, 64~1600으로 맞춘다."""
    try:
        v = int(float(v))
    except (TypeError, ValueError):
        return default
    return min(1600, max(64, round(v / 64) * 64))


def clamp01(v, default):
    """화면·제미나이에서 온 값은 믿지 않는다. 0~1로 자른다."""
    try:
        return min(1.0, max(0.0, float(v)))
    except (TypeError, ValueError):
        return default


REF_TYPES = ("character&style", "character", "style")

# 값 목록은 novelai-sdk constants/types 기준
MODELS = {
    "nai-diffusion-5-full": "V5 Full", "nai-diffusion-5-curated": "V5 Curated",
    "nai-diffusion-4-5-full": "V4.5 Full", "nai-diffusion-4-5-curated": "V4.5 Curated",
    "nai-diffusion-4-full": "V4 Full", "nai-diffusion-4-curated": "V4 Curated",
    "nai-diffusion-3": "V3", "nai-diffusion-3-furry": "V3 Furry",
}
SAMPLERS = ("k_euler_ancestral", "k_euler", "k_dpmpp_2s_ancestral",
            "k_dpmpp_2m", "k_dpmpp_sde", "ddim")
NOISE_SCHEDULES = ("karras", "exponential", "polyexponential")

DEFAULT_SETTINGS = {
    "model": "nai-diffusion-4-5-full",
    "prefix": "",        # 고정 프롬프트 — 매번 맨 앞에
    "negative": "",      # 고정 네거티브 — 매번 맨 앞에
    "steps": 28, "scale": 5.0, "cfg_rescale": 0.0,
    "sampler": "k_euler_ancestral", "noise_schedule": "karras",
    "width": 832, "height": 1216,
}


def is_v4plus(model):
    """V4 이후는 프롬프트를 v4_prompt 구조로도 보낸다. V3는 아니다."""
    return not model.startswith("nai-diffusion-3")


def is_v45(model):
    """정밀 레퍼런스는 V4.5에서만 된다."""
    return model.startswith("nai-diffusion-4-5")


def clean_settings(new, base=None):
    """부분 수정을 받아 검증된 전체 설정을 돌려준다. 잘못된 값은 이전 값을 유지한다."""
    out = dict(base or DEFAULT_SETTINGS)
    new = new or {}

    def num(k, lo, hi, cast):
        if k in new:
            try:
                out[k] = cast(min(hi, max(lo, cast(float(new[k])))))
            except (TypeError, ValueError):
                pass

    if new.get("model") in MODELS:
        out["model"] = new["model"]
    for k in ("prefix", "negative"):
        if k in new and isinstance(new[k], str):
            out[k] = new[k].strip()[:2000]
    # 예전 판의 '고정 프롬프트(뒤)'는 한 칸으로 합쳤다. 저장돼 있던 값은 뒤에 이어 붙여 살린다
    if isinstance(new.get("suffix"), str) and new["suffix"].strip():
        out["prefix"] = join_tags(out["prefix"], new["suffix"])[:2000]
    num("steps", 1, 50, int)
    num("scale", 0, 10, float)
    num("cfg_rescale", 0, 1, float)
    if new.get("sampler") in SAMPLERS:
        out["sampler"] = new["sampler"]
    if new.get("noise_schedule") in NOISE_SCHEDULES:
        out["noise_schedule"] = new["noise_schedule"]
    for k, d in (("width", 832), ("height", 1216)):
        if k in new:
            out[k] = snap64(new[k], out.get(k, d))
    return out


def join_tags(*parts):
    """고정 프롬프트와 이번 프롬프트를 쉼표로 잇는다. 빈 칸과 끝 쉼표는 정리한다."""
    return ", ".join(p.strip().strip(",").strip() for p in parts if p and p.strip().strip(","))


def build_payload(prompt, negative="", width=832, height=1216, seed=1,
                  model="nai-diffusion-4-5-full", i2i=None, ref=None, opts=None):
    """NovelAI generate-image 요청 본문.
    필드 이름은 NovelAI 웹 클라이언트에서 캡처한 요청(NekoAI-API)과
    novelai-sdk 타입 정의를 따른다.
      i2i  = {"image": b64, "strength": 0~1, "noise": 0~1}
      ref  = {"image": b64, "type": REF_TYPES, "strength": 0~1, "fidelity": 0~1}
      opts = steps / scale / sampler / noise_schedule / cfg_rescale"""
    o = clean_settings(opts or {})
    p = {"width": width, "height": height, "n_samples": 1, "steps": o["steps"],
         "scale": o["scale"], "cfg_rescale": o["cfg_rescale"], "seed": seed,
         "sampler": o["sampler"], "noise_schedule": o["noise_schedule"],
         "params_version": 3, "negative_prompt": negative}
    if is_v4plus(model):
        p["v4_prompt"] = {"caption": {"base_caption": prompt, "char_captions": []},
                          "use_coords": False, "use_order": True}
        p["v4_negative_prompt"] = {"caption": {"base_caption": negative, "char_captions": []},
                                   "legacy_uc": False}
    action = "generate"
    if i2i:
        p.update(image=i2i["image"], strength=clamp01(i2i.get("strength"), 0.6),
                 noise=clamp01(i2i.get("noise"), 0.0), extra_noise_seed=seed)
        action = "img2img"
    if ref:
        kind = ref.get("type") if ref.get("type") in REF_TYPES else REF_TYPES[0]
        p.update(director_reference_images=[ref["image"]],
                 director_reference_descriptions=[
                     {"caption": {"base_caption": kind, "char_captions": []}, "legacy_uc": False}],
                 director_reference_strength_values=[clamp01(ref.get("strength"), 1.0)],
                 # 웹 화면의 '충실도'는 API에선 1-충실도로 들어간다
                 director_reference_secondary_strength_values=[
                     round(1 - clamp01(ref.get("fidelity"), 1.0), 2)],
                 director_reference_information_extracted=[1.0])
    return {"input": prompt, "model": model, "action": action, "parameters": p}


def _open_rgb(data):
    from PIL import Image          # util은 PIL 없이도 import 되게 둔다
    return Image.open(io.BytesIO(data)).convert("RGB")


def _png_b64(img):
    import base64
    buf = io.BytesIO()
    img.save(buf, "PNG")
    return base64.b64encode(buf.getvalue()).decode()


def prep_i2i(data):
    """I2I 원본: 비율 유지, 64 배수로 맞춤. (b64, 가로, 세로)"""
    img = _open_rgb(data)
    w, h = fit64(*img.size)
    return _png_b64(img.resize((w, h))), w, h


def prep_reference(data, size=(1024, 1536)):
    """정밀 레퍼런스: 1024x1536 캔버스에 비율 유지로 넣고 남는 곳은 검은색."""
    from PIL import Image
    img = _open_rgb(data)
    s = min(size[0] / img.width, size[1] / img.height)
    img = img.resize((max(1, int(img.width * s)), max(1, int(img.height * s))), Image.LANCZOS)
    canvas = Image.new("RGB", size, (0, 0, 0))
    canvas.paste(img, ((size[0] - img.width) // 2, (size[1] - img.height) // 2))
    return _png_b64(canvas)


# ---------- 아날스 추정 ----------
# novelai-sdk utils/anlas.py 공식 그대로. 웹 화면을 역산한 값이라 추정치다.
_AREA_K = 2.951823174884865e-6
_STEP_AREA_K = 5.753298233447344e-7
_OPUS_FREE_PIXELS = 1_048_576
_OPUS_FREE_STEPS = 28
_REF_EXTRA = 5


def estimate_anlas(width, height, steps, i2i_strength=None, refs=0, is_opus=False, n=1):
    """한 번 생성에 드는 아날스. (총합, 설명)"""
    from math import ceil
    area = width * height
    base = ceil(_AREA_K * area + _STEP_AREA_K * area * steps)
    factor = i2i_strength if i2i_strength is not None else 1.0
    per = max(ceil(base * factor), 2)   # NovelAI 한도 140은 이 앱 최대치(1600², 50스텝 = 82)로 못 넘는다
    free = is_opus and area <= _OPUS_FREE_PIXELS and steps <= _OPUS_FREE_STEPS
    billable = max(n - 1, 0) if free else n
    ref_cost = refs * _REF_EXTRA * n          # 레퍼런스 추가분은 Opus 무료와 상관없이 붙는다
    total = per * billable + ref_cost
    parts = []
    if per * billable:
        parts.append(f"기본 {per * billable}")
    elif free:
        parts.append("기본 0 (Opus 무료 범위)")
    if ref_cost:
        parts.append(f"정밀 레퍼런스 +{ref_cost}")
    return total, " · ".join(parts) or "0"


# ---------- 그림 메타데이터(EXIF) 읽기 ----------
_STEALTH_MAGIC = b"stealth_pngcomp"


def _stealth_json(img):
    """NovelAI가 알파 채널 최하위 비트에 숨긴 메타데이터.
    NovelAI 공식 nai_meta.py와 같은 순서: 알파를 전치(세로 줄 순서)해서 비트를 모은다.
    텍스트 청크를 지우는 사이트를 거쳐도 여기엔 남는다."""
    import gzip, json
    if "A" not in img.getbands():
        return None
    from PIL import Image
    col_major = img.getchannel("A").transpose(Image.TRANSPOSE).tobytes()

    def read(start, n):
        out = bytearray()
        for i in range(start, start + n):
            chunk = col_major[i * 8:i * 8 + 8]
            if len(chunk) < 8:
                return None
            v = 0
            for c in chunk:
                v = (v << 1) | (c & 1)
            out.append(v)
        return bytes(out)

    if read(0, len(_STEALTH_MAGIC)) != _STEALTH_MAGIC:
        return None
    ln = read(len(_STEALTH_MAGIC), 4)
    if not ln:
        return None
    nbytes = int.from_bytes(ln, "big") // 8
    data = read(len(_STEALTH_MAGIC) + 4, nbytes)
    if not data:
        return None
    return json.loads(gzip.decompress(data).decode("utf-8"))


def _exif_user_comment(img):
    """JPEG·WebP의 EXIF UserComment (A1111이 JPEG에 파라미터를 넣는 곳)."""
    try:
        raw = img.getexif().get_ifd(0x8769).get(0x9286)
    except Exception:
        return None
    if not raw:
        return None
    if isinstance(raw, str):
        return raw
    head, body = raw[:8], raw[8:]
    if head.startswith(b"UNICODE"):
        for enc in ("utf-16-be", "utf-16-le"):
            try:
                t = body.decode(enc)
                if t.isprintable() or "\n" in t:
                    return t
            except UnicodeDecodeError:
                pass
    return body.decode("utf-8", "ignore") or None


def _guess_model(source):
    s = (source or "").lower()
    curated = "curated" in s
    for key, full, cur in (("v5", "nai-diffusion-5-full", "nai-diffusion-5-curated"),
                           ("v4.5", "nai-diffusion-4-5-full", "nai-diffusion-4-5-curated"),
                           ("v4", "nai-diffusion-4-full", "nai-diffusion-4-curated")):
        if key in s:
            return cur if curated else full
    if "xl" in s or "v3" in s:          # V3는 'Stable Diffusion XL ...'로 적힌다
        return "nai-diffusion-3"
    return None


def _from_nai(info, source):
    import json
    c = info.get("Comment")
    if isinstance(c, str):
        try:
            c = json.loads(c)
        except ValueError:
            c = {}
    c = c or {}
    v4p = ((c.get("v4_prompt") or {}).get("caption") or {}).get("base_caption")
    v4n = ((c.get("v4_negative_prompt") or {}).get("caption") or {}).get("base_caption")
    params = {k: c[k] for k in ("steps", "scale", "cfg_rescale", "sampler", "noise_schedule",
                                "width", "height", "seed") if k in c}
    return {"found": True, "source": source,
            "prompt": v4p or c.get("prompt") or info.get("Description") or "",
            "negative": v4n if v4n is not None else (c.get("uc") or ""),
            "params": params, "model_guess": _guess_model(info.get("Source")),
            "software": info.get("Software") or "NovelAI"}


def _from_a1111(text):
    """'프롬프트\nNegative prompt: ...\nSteps: 28, Sampler: ..., CFG scale: 7, Seed: 1, Size: 512x768'"""
    import re as _re
    prompt, _, rest = text.partition("\nNegative prompt:")
    if not rest:
        prompt, _, tail = text.partition("\nSteps:")
        negative, tail = "", ("Steps:" + tail) if tail else ""
    else:
        negative, _, tail = rest.partition("\nSteps:")
        tail = ("Steps:" + tail) if tail else ""
    params = {}
    m = _re.search(r"Steps:\s*(\d+)", tail)
    if m:
        params["steps"] = int(m.group(1))
    m = _re.search(r"CFG scale:\s*([\d.]+)", tail)
    if m:
        params["scale"] = float(m.group(1))
    m = _re.search(r"Seed:\s*(\d+)", tail)
    if m:
        params["seed"] = int(m.group(1))
    m = _re.search(r"Size:\s*(\d+)x(\d+)", tail)
    if m:
        params["width"], params["height"] = int(m.group(1)), int(m.group(2))
    return {"found": True, "source": "a1111", "prompt": prompt.strip(), "negative": negative.strip(),
            "params": params, "model_guess": None, "software": "Stable Diffusion WebUI"}


def read_metadata(data):
    """그림 바이트에서 생성 정보를 꺼낸다. 순서: NovelAI 텍스트 청크 → NovelAI 알파 채널 → A1111."""
    from PIL import Image
    img = Image.open(io.BytesIO(data))
    info = dict(img.info)
    if "Comment" in info and ("NovelAI" in str(info.get("Software", "")) or "prompt" in str(info["Comment"])):
        return _from_nai(info, "novelai")
    try:
        st = _stealth_json(img)
    except Exception:
        st = None
    if st:
        return _from_nai(st, "novelai-stealth")
    text = info.get("parameters") or _exif_user_comment(img)
    if isinstance(text, bytes):
        text = text.decode("utf-8", "ignore")
    if text and text.strip():
        return _from_a1111(text)
    return {"found": False, "source": None, "prompt": "", "negative": "", "params": {},
            "model_guess": None, "software": None}


def strip_metadata(data):
    """생성 정보·EXIF·위치 정보를 지운 그림 바이트와 확장자를 돌려준다.
    픽셀만 새 그림으로 옮기므로 PNG 텍스트 청크·EXIF·XMP가 따라가지 않는다.
    NovelAI 알파 채널 정보는 알파 최하위 비트를 1로 채워 지운다(불투명도 차이 1/255, 눈으로 안 보임)."""
    from PIL import Image, ImageOps
    img = Image.open(io.BytesIO(data))
    fmt = img.format
    img = ImageOps.exif_transpose(img)            # EXIF 회전값을 픽셀에 반영해야 지운 뒤에도 안 돌아간다
    if img.mode not in ("RGB", "RGBA", "L"):
        img = img.convert("RGBA" if "transparency" in img.info or "A" in img.getbands() else "RGB")
    if img.mode == "RGBA":
        r, g, b, a = img.split()
        img = Image.merge("RGBA", (r, g, b, a.point(lambda v: v | 1)))
    clean = Image.frombytes(img.mode, img.size, img.tobytes())
    out = io.BytesIO()
    if fmt == "JPEG":
        clean.convert("RGB").save(out, "JPEG", quality=95)
        return out.getvalue(), ".jpg"
    if fmt == "WEBP":
        clean.save(out, "WEBP", quality=95)
        return out.getvalue(), ".webp"
    clean.save(out, "PNG")
    return out.getvalue(), ".png"
