# NAI 채팅 (Cloud Run)

폰에서 한국어로 말하면 제미나이가 태그로 바꿔 NovelAI로 그림을 생성한다.
PC를 꺼도 돌아간다. 파일은 Cloud Storage 버킷의 `files/` 아래에 보관한다.

## 기능

- 채팅으로 그림 생성. 만든 그림은 보관함에 자동 저장 (`gen-날짜-시각-xxxx.png`)
- 📎 파일 올리기. 올린 그림은 두 가지로 쓴다
  - **I2I** — 그 그림의 구도·포즈를 살려 변형 ("이 그림에서 옷만 바꿔")
  - **정밀 레퍼런스** — 구도는 새로, 캐릭터·화풍만 따라감 ("이 캐릭터로 다른 장면"). 장당 5 Anlas 추가
- 🎛 생성 설정 패널: 제미나이가 실제로 넣은 프롬프트·크기·시드·참고 그림·강도를 보여주고,
  값을 바꿔 제미나이 없이 바로 다시 생성. 채팅의 그림을 누르면 그 그림의 설정을 불러온다
- ⚙ 고정 설정 (서버 저장, 모든 생성에 적용): 모델 · 고정 프롬프트 · 고정 네거티브 ·
  스텝 · 가이던스 · CFG 리스케일 · 샘플러 · 노이즈 스케줄 · 기본 크기(세로/가로 프리셋).
  채팅으로 "5 full로 바꿔", "스텝 35로 고정해"처럼 말해도 바뀐다
- 💎 아날스 확인: 뽑기 직전에 예상 소모량을 계산해 **0이면 바로, 1 이상이면 승인을 받아야** 뽑는다.
  승인 검사는 서버가 하므로 화면 버그로 허락 없이 빠지지 않는다. 뽑은 뒤 잔액을 다시 읽어 실제 소모량도 보여준다.
  계산식은 novelai-sdk의 추정 공식(웹 화면 역산)이라 실제와 다를 수 있다. 헤더에 잔액 표시
- 🔎 EXIF 추출 (채팅으로): "이거 EXIF 추출해줘", "이 그림 네거티브 고정 네거티브에 넣어".
  읽는 순서: NovelAI PNG 텍스트 청크 → NovelAI 알파 채널(공식 nai_meta.py 규격, SNS가 텍스트를 지워도 남음) →
  Stable Diffusion WebUI(PNG `parameters`, JPEG EXIF UserComment)
- 🧽 EXIF 제거 (채팅으로): "이거 EXIF 지워줘". 텍스트 청크·EXIF·위치 정보·알파 채널 정보를 모두 지운 사본을
  `이름-noexif.png`로 저장하고 원본은 둔다. 알파 최하위 비트를 1로 채워 지우므로 불투명도가 최대 1/255 바뀐다.
  JPEG는 다시 압축(품질 95)되고, 회전 정보는 픽셀에 반영한 뒤 지운다
- 📁 보관함: 목록 · 받기 · 선택 ZIP 받기 · 선택 삭제
- 채팅으로 "이거 zip으로 묶어줘" → 보관함에 zip 저장
- 올린 파일이 `ZIP_OVER_MB`(기본 5MB) 이상이고 압축해서 10% 넘게 줄면 `이름.zip`으로 저장. 이미지는 항상 원본

## 설치 (처음부터)

### 0. 준비물

- 결제 계정이 연결된 구글 클라우드 프로젝트
- NovelAI 유료 구독 + persistent API token (NovelAI → 설정 → Account)
- `nai-chat.zip`

### 1. 클라우드 셸 열기

console.cloud.google.com 오른쪽 위 `>_` 아이콘. 프로젝트 확인:

```bash
gcloud config get-value project
```

다른 프로젝트에 올리려면 `gcloud config set project 프로젝트ID`.

### 2. 파일 올리고 풀기

셸 오른쪽 위 ⋮ → 업로드 → `nai-chat.zip`.

```bash
cd ~ && rm -rf nai-chat && unzip -o nai-chat.zip -d nai-chat && cd nai-chat && ls
```

`index.html`이 보여야 한다.

### 3. API 켜기 (1~2분, 출력 없이 조용히 진행됨)

```bash
gcloud services enable compute.googleapis.com run.googleapis.com cloudbuild.googleapis.com aiplatform.googleapis.com storage.googleapis.com artifactregistry.googleapis.com
```

### 4. 권한 주기 + 버킷 만들기

```bash
PROJ=$(gcloud config get-value project)
NUM=$(gcloud projects describe $PROJ --format='value(projectNumber)')
SA=$NUM-compute@developer.gserviceaccount.com
for R in roles/cloudbuild.builds.builder roles/storage.objectViewer roles/artifactregistry.writer roles/logging.logWriter roles/aiplatform.user; do
  gcloud projects add-iam-policy-binding $PROJ --member=serviceAccount:$SA --role=$R --quiet >/dev/null
done
gcloud storage buckets create gs://$PROJ-nai-files --location=asia-northeast3 --uniform-bucket-level-access
gcloud storage buckets add-iam-policy-binding gs://$PROJ-nai-files --member=serviceAccount:$SA --role=roles/storage.objectAdmin
```

권한이 퍼지는 데 1분쯤 걸린다.

### 5. 배포 (5분 안팎)

`암호`와 `토큰` 자리만 바꾼다. 암호는 영문·숫자로.

```bash
gcloud run deploy nai-chat --source . --region asia-northeast3 --allow-unauthenticated --timeout 300 \
  --set-env-vars GOOGLE_CLOUD_PROJECT=$PROJ,BUCKET=$PROJ-nai-files,APP_PASSWORD=암호,NAI_TOKEN=토큰
```

저장소를 만들지 물으면 `Y`. 끝나면 `Service URL: https://nai-chat-….run.app`이 나온다.
그 주소를 폰에 저장하면 끝. 셸과 PC를 꺼도 된다.

**이 명령줄을 캡처해서 공유하지 말 것.** 토큰과 암호가 그대로 보인다.

## 고친 코드를 다시 올릴 때

2번(파일 올리고 풀기) 후 이것만. 환경변수는 이전 값이 그대로 유지된다.

```bash
gcloud run deploy nai-chat --source . --region asia-northeast3
```

값을 바꿀 때는 `--update-env-vars`. **`--set-env-vars`는 나머지 값을 전부 지운다.**

```bash
gcloud run services update nai-chat --region asia-northeast3 --update-env-vars APP_PASSWORD=새암호
```

## 문제 해결

| 증상 | 원인 · 해결 |
|---|---|
| 배포 중 `storage.objects.get` 403 | 4번 권한이 아직 안 퍼짐. 1분 뒤 다시 배포 |
| 채팅에 `PermissionDenied` / `RetryError` | `roles/aiplatform.user` 누락. 4번 다시 |
| 채팅에 `NotFound` / 404 | 제미나이 모델명. `--update-env-vars MODEL=다른모델` |
| `NovelAI 401` | 토큰이 틀림 또는 구독 없음 |
| 헤더 잔액이 `💎 ?` | 구독 정보를 못 읽음. 이때는 Opus가 아닌 것으로 보고 매번 승인을 묻는다 |
| `NovelAI 400` | NAI 모델명·파라미터. `--update-env-vars NAI_MODEL=정확한이름` |
| 보관함에 `Forbidden` | 버킷 `objectAdmin` 권한 누락. 4번 마지막 줄 |
| 원인 확인 | `gcloud run services logs read nai-chat --region asia-northeast3 --limit 30` |

## 환경 변수

| 이름 | 용도 |
|---|---|
| `GOOGLE_CLOUD_PROJECT` | 버텍스 호출용 프로젝트 |
| `BUCKET` | 파일 보관 버킷 이름 |
| `NAI_TOKEN` | NovelAI persistent API token |
| `APP_PASSWORD` | 접속 비밀번호. 비우면 누구나 들어옴 |
| `MODEL` | 기본 `gemini-2.5-flash` |
| `NAI_MODEL` | 고정 설정을 한 번도 저장하지 않았을 때의 기본 모델. 이후엔 설정 화면이 우선 |
| `LOCATION` | 기본 `global` |
| `ZIP_OVER_MB` | 자동 압축 기준 크기. 기본 5 |

## 알려진 한계

- 정밀 레퍼런스는 V4.5 모델에서만 된다 (서버가 막는다)
- 고정 설정은 버킷의 `config/settings.json`. 보관함 목록에는 안 뜬다

- 바이브 트랜스퍼는 없음. 그림을 먼저 `/ai/encode-vibe`로 인코딩해야 해서 따로 붙여야 한다

- ZIP은 메모리에서 묶는다. 한 번에 수백 MB를 넘기면 스트리밍으로 바꿀 것
- 업로드 한 번에 30MB까지 (클라우드 런 요청 한도 32MB)
- 같은 이름으로 올리면 덮어쓴다
- 요금: 클라우드 런·스토리지는 무료 한도가 크지만 제미나이 호출은 건당 과금
